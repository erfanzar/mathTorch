# mathTorch

 mathTorchis a Python library for deep learning from scratch.

## Installation

Use the package manager [pip](none) to install mathTorch.

```bash
pip install mathTorch --user
```

## Usage

```python
import mathTorch.nn as nn

# Creating just a simple Layer

linear = nn.Linear(1,5)
relu = nn.ReLU()

# x you input data

x = relu(linear(x))


```

## Beta

This Package is still in beta mode and I'm working on it

Please make sure to update tests as appropriate.

## License

[MIT](https://choosealicense.com/licenses/mit/)